/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

import {GoogleGenAI} from '@google/genai';

// API_KEY is expected to be set in the environment.

function displayMessage(elementId: string, message: string, isError: boolean = false) {
  const element = document.getElementById(elementId);
  if (element) {
    element.textContent = message;
    if (elementId === 'output-message') {
        element.style.color = isError ? 'var(--error-text-color)' : 'var(--text-color)';
        const container = document.getElementById('output-container');
        if (container) {
            container.style.borderColor = isError ? 'var(--error-border-color)' : 'var(--output-border-color)';
            container.style.backgroundColor = isError ? 'var(--error-bg-color)' : 'var(--output-bg-color)';
        }
    }
  } else {
    console.error(`Element with ID '${elementId}' not found.`);
  }
}

async function countTokens(textToCount: string) {
  
  const trimmedText = textToCount.trim();

  if (!trimmedText) {
    displayMessage('output-message', 'Please enter some text to count tokens.', true);
    displayMessage('input-text', "Enter text above and click 'Count Tokens'.");
    return;
  }

  let processingMessage = `Processing text: "${trimmedText.substring(0, 50)}${trimmedText.length > 50 ? '...' : ''}"`;
  
  displayMessage('input-text', processingMessage);
  displayMessage('output-message', 'Counting tokens...');
  const outputContainer = document.getElementById('output-container');
  if (outputContainer) {
      outputContainer.style.borderColor = 'var(--output-border-color)';
      outputContainer.style.backgroundColor = 'var(--output-bg-color)';
  }

  try {
    const ai = new GoogleGenAI({apiKey: process.env.API_KEY});

    const response = await ai.models.countTokens({
      model: 'gemini-2.5-flash',
      contents: trimmedText,
    });

    displayMessage('output-message', `Total tokens: ${response.totalTokens}`);
  } catch (e) {
    console.error('Error counting tokens:', e);
    const errorMessage = e instanceof Error ? e.message : String(e);
    displayMessage('output-message', `Error: Failed to count tokens. ${errorMessage}`, true);
  }
}

function setupEventListeners() {
  const countButton = document.getElementById('count-button');
  const userInputArea = document.getElementById('user-input-area') as HTMLTextAreaElement;

  if (countButton && userInputArea) {
    countButton.addEventListener('click', () => {
      const inputText = userInputArea.value;
      countTokens(inputText);
    });
  } else {
    console.error('Could not find one or more required elements: button or textarea.');
  }
}

async function main() {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setupEventListeners);
  } else {
    setupEventListeners();
  }
  // Set initial messages
  displayMessage('input-text', "Enter text above, then click 'Count Tokens'.");
  displayMessage('output-message', "Results will appear here.");
}

main();
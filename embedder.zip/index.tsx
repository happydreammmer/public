/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

import {GoogleGenAI} from '@google/genai';

const fileInput = document.getElementById('fileInput') as HTMLInputElement;
const embedButton = document.getElementById('embedButton') as HTMLButtonElement;
const downloadButton = document.getElementById('downloadButton') as HTMLButtonElement;
const resultsOutput = document.getElementById('resultsOutput') as HTMLPreElement;
const loadingIndicator = document.getElementById('loadingIndicator') as HTMLDivElement;

let currentFileContents: string[] = [];
let currentEmbeddingVector: number[] | null = null;

function showLoading(isLoading: boolean) {
  if (isLoading) {
    loadingIndicator.style.display = 'block';
    embedButton.disabled = true;
    downloadButton.style.display = 'none';
    resultsOutput.textContent = ''; 
    resultsOutput.style.color = 'inherit';
    currentEmbeddingVector = null;
  } else {
    loadingIndicator.style.display = 'none';
    // Enable button only if there are files ready to be processed
    embedButton.disabled = currentFileContents.length === 0;
  }
}

function displayResult(message: string, isError = false) {
  resultsOutput.textContent = message;
  resultsOutput.style.color = isError ? 'var(--error-color)' : 'var(--text-color-results)';
  if (isError && !currentEmbeddingVector) { 
    // If it's an error message AND there's no current vector to download, hide the button.
    // This prevents hiding download if an error message is shown for file loading but a previous vector exists.
    downloadButton.style.display = 'none';
  }
}

async function generateEmbeddings(texts: string[]) {
  showLoading(true);
  try {
    const ai = new GoogleGenAI({apiKey: process.env.API_KEY});

    // The `contents` field expects an array of strings for batch embedding,
    // or a single string. The response structure might differ based on this.
    // The error message suggests `response.embeddings` is the correct path.
    const response = await ai.models.embedContent({
      model: 'text-embedding-004',
      contents: texts, 
    });

    // Corrected access to embedding values based on common API patterns and TS error hint
    if (response.embeddings && response.embeddings.length > 0 && response.embeddings[0] && response.embeddings[0].values) {
      currentEmbeddingVector = response.embeddings[0].values; // Using the first embedding
      
      let successMessage = `Embedding generated.`;
      if (texts.length > 1) {
        successMessage = `Embeddings generated for ${texts.length} file(s). Displaying the embedding for the first file/content part.`;
      } else {
        successMessage = `Embedding generated for the uploaded file.`;
      }
      successMessage += `\n${JSON.stringify(currentEmbeddingVector, null, 2)}`;
      displayResult(successMessage);
      downloadButton.style.display = 'block';
    } else {
      displayResult('Error: Embedding data not found or is malformed in API response. The response might be empty or malformed.', true);
      currentEmbeddingVector = null;
      downloadButton.style.display = 'none';
    }
  } catch (e: any) {
    console.error('Error generating embeddings:', e);
    const errorMessage = e.message || 'An unknown API error occurred. Please check the console for details.';
    displayResult(`Error generating embeddings: ${errorMessage}`, true);
    currentEmbeddingVector = null;
    downloadButton.style.display = 'none';
  } finally {
    showLoading(false);
    if (fileInput) {
        fileInput.value = ''; 
    }
    // currentFileContents are cleared here to ensure a fresh state for next operation
    // This also ensures embedButton is disabled as per showLoading(false) logic if currentFileContents is empty
    currentFileContents = []; 
    embedButton.disabled = true; // Explicitly disable after an operation
  }
}

async function handleFileSelect(event: Event) {
  const target = event.target as HTMLInputElement;
  const files = target.files;

  currentFileContents = [];
  currentEmbeddingVector = null; // Clear previous vector on new file selection
  downloadButton.style.display = 'none'; // Hide download button
  embedButton.disabled = true; // Disable button until files are processed
  resultsOutput.style.color = 'var(--text-color-results)'; // Reset color for file loading messages

  if (!files || files.length === 0) {
    displayResult('No files selected. Please choose one or more text files.', true);
    return;
  }

  displayResult(`Loading ${files.length} file(s)...`);

  const fileReadPromises = Array.from(files).map(file => {
    return new Promise<{ name: string, content: string, size: number }>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        // Allow empty string content, but reject if content is null/undefined (true read error)
        if (content !== null && content !== undefined) {
          resolve({ name: file.name, content, size: file.size });
        } else {
           reject(new Error(`Could not read content from "${file.name}".`));
        }
      };
      reader.onerror = () => {
        reject(new Error(`Error reading file "${file.name}": ${reader.error?.message || 'Unknown error'}`));
      };
      reader.readAsText(file);
    });
  });

  const results = await Promise.allSettled(fileReadPromises);

  const successfullyReadFiles: { name: string, content: string, size: number }[] = [];
  const errorMessages: string[] = [];

  results.forEach(result => {
    if (result.status === 'fulfilled') {
      successfullyReadFiles.push(result.value);
    } else {
      errorMessages.push(result.reason.message);
    }
  });

  if (successfullyReadFiles.length > 0) {
    currentFileContents = successfullyReadFiles.map(f => f.content);
    
    const loadedFileNames = successfullyReadFiles.map(f => `${f.name} (${Math.round(f.size / 1024)} KB)`).join(', ');
    let message = `Successfully loaded ${successfullyReadFiles.length} file(s): ${loadedFileNames}. Ready to generate embeddings.`;
    
    if (errorMessages.length > 0) {
      message += `\n${errorMessages.length} file(s) could not be loaded: ${errorMessages.join('; ')}.`;
      displayResult(message, true); // true because there were errors, even if partial success
    } else {
      displayResult(message, false);
    }
    embedButton.disabled = false;
  } else {
    displayResult(`Failed to load any files. Errors: ${errorMessages.join('; ')}`, true);
    embedButton.disabled = true;
  }
}

fileInput.addEventListener('change', handleFileSelect);

embedButton.addEventListener('click', async () => {
  if (currentFileContents.length > 0) {
    await generateEmbeddings(currentFileContents);
  } else {
    displayResult('Please select one or more text files first.', true);
    downloadButton.style.display = 'none';
    currentEmbeddingVector = null;
  }
});

downloadButton.addEventListener('click', () => {
  if (currentEmbeddingVector) {
    const jsonString = JSON.stringify(currentEmbeddingVector, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'embedding_vector.json'; // Changed from _combined as we show first if multiple
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  } else {
    displayResult('No vector data available to download.', true);
  }
});

// Initial state
embedButton.disabled = true;
downloadButton.style.display = 'none';
showLoading(false);
displayResult('Upload text file(s) and click "Generate Embeddings" to see their combined vector representation.');

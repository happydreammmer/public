export type Sender = 'user' | 'bot';

export interface GroundingChunk {
  web?: {
    uri?: string;
    title?: string;
  };
}

export interface Message {
  id: string;
  sender: Sender;
  text: string;
  groundingChunks?: GroundingChunk[];
  isLoading?: boolean;
}
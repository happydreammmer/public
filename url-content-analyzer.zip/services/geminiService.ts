import { GoogleGenAI, Chat } from "@google/genai";

if (!process.env.API_KEY) {
  throw new Error("The API_KEY environment variable must be set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Creates a new chat session with the Gemini API.
 * The session is configured to use the urlContext tool,
 * allowing it to access and process content from a specific URL.
 * @returns {Chat} A new Chat instance.
 */
export function createChatSession(): Chat {
  const chat = ai.chats.create({
    model: 'gemini-2.5-flash',
    config: {
        tools: [{ urlContext: {} }],
    }
  });
  return chat;
}

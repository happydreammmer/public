
import React from 'react';
import { LinkIcon, SpinnerIcon } from './Icons';

interface UrlInputFormProps {
  url: string;
  setUrl: (url: string) => void;
  onSubmit: (e: React.FormEvent) => void;
  isLoading: boolean;
}

const UrlInputForm: React.FC<UrlInputFormProps> = ({ url, setUrl, onSubmit, isLoading }) => {
  return (
    <form onSubmit={onSubmit} className="w-full">
      <div className="relative">
        <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4">
          <LinkIcon />
        </div>
        <input
          type="url"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="Enter a URL to analyze..."
          disabled={isLoading}
          required
          className="w-full rounded-full border-2 border-base-300 bg-base-100 py-4 pl-12 pr-32 text-lg text-text-primary transition-colors duration-300 focus:border-brand-primary focus:outline-none focus:ring-2 focus:ring-brand-primary disabled:opacity-50"
        />
        <button
          type="submit"
          disabled={isLoading}
          className="absolute inset-y-0 right-0 m-2 flex items-center justify-center rounded-full bg-brand-primary px-6 font-bold text-white transition-transform duration-200 hover:scale-105 active:scale-95 disabled:scale-100 disabled:bg-base-300 disabled:opacity-70"
        >
          {isLoading ? <SpinnerIcon /> : 'Analyze'}
        </button>
      </div>
    </form>
  );
};

export default UrlInputForm;

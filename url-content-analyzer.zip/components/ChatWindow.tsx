import React, { useState, useRef, useEffect } from 'react';
import type { Message } from '../types';
import { BotIcon, UserIcon, SendIcon, SpinnerIcon, LinkIcon } from './Icons';

interface ChatMessageProps {
  message: Message;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isBot = message.sender === 'bot';

  return (
    <div className={`flex items-start gap-4 ${isBot ? '' : 'flex-row-reverse'}`}>
      <div className={`flex-shrink-0 rounded-full p-2 ${isBot ? 'bg-base-300 text-brand-secondary' : 'bg-brand-primary text-white'}`}>
        {isBot ? <BotIcon /> : <UserIcon />}
      </div>
      <div className={`w-full max-w-2xl rounded-xl p-4 shadow-md ${isBot ? 'bg-base-200' : 'bg-brand-primary'}`}>
        {message.isLoading ? (
          <div className="flex items-center gap-2 text-text-secondary">
             <div className="h-2 w-2 animate-pulse-fast rounded-full bg-brand-secondary [animation-delay:-0.3s]"></div>
             <div className="h-2 w-2 animate-pulse-fast rounded-full bg-brand-secondary [animation-delay:-0.15s]"></div>
             <div className="h-2 w-2 animate-pulse-fast rounded-full bg-brand-secondary"></div>
          </div>
        ) : (
          <p className="whitespace-pre-wrap text-text-primary">{message.text}</p>
        )}
        
        {message.groundingChunks && message.groundingChunks.length > 0 && (
          <div className="mt-4 border-t border-base-300 pt-3">
            <h4 className="mb-2 text-sm font-semibold text-text-secondary">Sources:</h4>
            <div className="flex flex-col gap-2">
              {message.groundingChunks.map((chunk, index) => (
                chunk.web && chunk.web.uri && (
                    <a
                      key={index}
                      href={chunk.web.uri}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 text-sm text-brand-secondary hover:underline"
                    >
                      <LinkIcon />
                      <span className="truncate">{chunk.web.title || chunk.web.uri}</span>
                    </a>
                )
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

interface ChatWindowProps {
  messages: Message[];
  isLoading: boolean;
  onSubmit: (message: string) => void;
  submittedUrl: string;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ messages, isLoading, onSubmit, submittedUrl }) => {
  const [input, setInput] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() && !isLoading) {
      onSubmit(input.trim());
      setInput('');
    }
  };

  return (
    <div className="flex h-full flex-col overflow-hidden rounded-2xl bg-base-100 shadow-2xl">
      <header className="flex-shrink-0 border-b border-base-300 bg-base-200/50 p-4">
          <p className="truncate text-sm text-text-secondary">
            Analysis of: <a href={submittedUrl} target="_blank" rel="noopener noreferrer" className="font-medium text-brand-secondary hover:underline">{submittedUrl}</a>
          </p>
      </header>
      
      <main className="flex-1 space-y-8 overflow-y-auto p-6">
        {messages.map((msg) => (
          <ChatMessage key={msg.id} message={msg} />
        ))}
        <div ref={scrollRef} />
      </main>

      <footer className="flex-shrink-0 border-t border-base-300 bg-base-100 p-4">
        <form onSubmit={handleSubmit} className="relative">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask a follow-up question..."
            className="w-full rounded-full border-2 border-base-300 bg-base-200 py-3 pl-5 pr-16 text-base text-text-primary focus:border-brand-primary focus:outline-none focus:ring-1 focus:ring-brand-primary"
          />
          <button
            type="submit"
            disabled={isLoading || !input.trim()}
            className="absolute inset-y-0 right-0 m-1.5 flex items-center justify-center rounded-full bg-brand-primary p-2.5 text-white transition-colors hover:bg-brand-secondary disabled:bg-base-300 disabled:text-text-secondary"
          >
            {isLoading ? <SpinnerIcon /> : <SendIcon />}
          </button>
        </form>
      </footer>
    </div>
  );
};

export default ChatWindow;
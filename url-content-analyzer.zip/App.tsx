
import React, { useState, useCallback } from 'react';
import type { Chat, GenerateContentResponse } from '@google/genai';
import { createChatSession } from './services/geminiService';
import type { Message } from './types';
import UrlInputForm from './components/UrlInputForm';
import ChatWindow from './components/ChatWindow';

export default function App() {
  const [url, setUrl] = useState<string>('');
  const [submittedUrl, setSubmittedUrl] = useState<string>('');
  const [chat, setChat] = useState<Chat | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const processStreamedMessage = useCallback(async (prompt: string, chatInstance: Chat, isFollowUp: boolean) => {
    setIsLoading(true);
    setError(null);
    
    if (isFollowUp) {
      setMessages(prev => [...prev, { id: Date.now().toString(), sender: 'user', text: prompt }]);
    }
    
    const botMessageId = (Date.now() + 1).toString();
    setMessages(prev => [...prev, { id: botMessageId, sender: 'bot', text: '', isLoading: true }]);

    try {
      const stream = await chatInstance.sendMessageStream({ message: prompt });
      let fullResponseText = '';
      let finalResponse: GenerateContentResponse | null = null;
      
      for await (const chunk of stream) {
        fullResponseText += chunk.text;
        finalResponse = chunk;
        setMessages(prev =>
          prev.map(msg =>
            msg.id === botMessageId ? { ...msg, text: fullResponseText } : msg
          )
        );
      }
      
      const groundingChunks = finalResponse?.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      setMessages(prev =>
        prev.map(msg =>
          msg.id === botMessageId ? { ...msg, isLoading: false, groundingChunks } : msg
        )
      );

    } catch (err) {
      console.error(err);
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
      setError(`Failed to get response: ${errorMessage}`);
      setMessages(prev => prev.filter(msg => msg.id !== botMessageId));
    } finally {
      setIsLoading(false);
    }
  }, []);

  const handleUrlSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) {
      setError("URL cannot be empty.");
      return;
    }
    
    try {
        new URL(url);
    } catch (_) {
        setError("Please enter a valid URL (e.g., https://example.com).");
        return;
    }

    setSubmittedUrl(url);
    setMessages([]);
    setError(null);

    const newChat = createChatSession();
    setChat(newChat);
    
    const initialPrompt = `Using ONLY the content from the webpage at this URL: ${url}, provide a comprehensive summary. Cover the main topic, key takeaways, and any notable facts or data. Structure your response clearly. Do not use any other sources.`;
    
    await processStreamedMessage(initialPrompt, newChat, false);
  }, [url, processStreamedMessage]);


  const handleFollowUpSubmit = useCallback(async (messageText: string) => {
    if (!chat) {
      setError("Chat session not initialized. Please analyze a URL first.");
      return;
    }
    await processStreamedMessage(messageText, chat, true);
  }, [chat, processStreamedMessage]);

  return (
    <div className="flex min-h-screen flex-col items-center bg-slate-900 p-4 sm:p-6 lg:p-8">
      <div className="w-full max-w-4xl">
        <header className="mb-6 text-center">
          <h1 className="text-4xl font-bold tracking-tight text-text-primary sm:text-5xl">
            URL Content Analyzer
          </h1>
          <p className="mt-2 text-lg text-text-secondary">
            Get instant summaries and ask questions about any webpage.
          </p>
        </header>

        <section className="mb-6">
          <UrlInputForm url={url} setUrl={setUrl} onSubmit={handleUrlSubmit} isLoading={isLoading && messages.length === 0} />
          {error && <p className="mt-2 text-center text-red-400">{error}</p>}
        </section>

        {submittedUrl && (
          <section className="h-[65vh] w-full">
            <ChatWindow 
              messages={messages}
              isLoading={isLoading}
              onSubmit={handleFollowUpSubmit}
              submittedUrl={submittedUrl}
            />
          </section>
        )}
      </div>
    </div>
  );
}
